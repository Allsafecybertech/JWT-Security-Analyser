import pytest
from jwt_security_analyser import analyser

def test_decode_jwt_valid():
    sample_token = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ."
        "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
    )
    header, payload = analyser.decode_jwt(sample_token)
    assert header is not None
    assert payload is not None
    assert header.get("alg") == "HS256"

def test_decode_jwt_invalid():
    header, payload = analyser.decode_jwt("invalid.token.value")
    assert header is None
    assert payload is None