import jwt
import sys

def decode_jwt(token):
    try:
        # Decode JWT without verification (for inspection)
        header = jwt.get_unverified_header(token)
        payload = jwt.decode(token, options={"verify_signature": False})
        return header, payload
    except Exception as e:
        print(f"Failed to decode JWT: {e}")
        return None, None

def basic_analysis(token):
    header, payload = decode_jwt(token)
    if header is None or payload is None:
        print("Invalid JWT.")
        return

    print("Header:", header)
    print("Payload:", payload)

    # Detect insecure algorithm
    alg = header.get("alg", "")
    if alg.lower() in ["none", "hs256"]:
        print(f"Warning: Insecure signing algorithm detected: {alg}")

    # Check for expiration
    if "exp" in payload:
        print("Token has expiration claim.")
    else:
        print("Warning: Token does not have expiration (exp) claim.")

    # Add more security checks as needed.

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Analyse JWT tokens for security issues.")
    parser.add_argument("--token", required=True, help="JWT token to analyse")
    args = parser.parse_args()
    basic_analysis(args.token)

if __name__ == "__main__":
    main()